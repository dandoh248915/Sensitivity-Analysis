# Deployment Instructions — Retail Macro Sensitivity Explorer

## Files needed
- `app.py` — the Streamlit application
- `retail_macro_data.csv` — the cleaned dataset
- `requirements.txt` — Python dependencies

## Steps to deploy on Streamlit Community Cloud

1. Create a new GitHub repository (can be private)
2. Upload all three files to the repository root
3. Go to share.streamlit.io and sign in
4. Click "New app"
5. Connect your GitHub repository
6. Set the main file path to: `app.py`
7. Click "Deploy"

Streamlit will install dependencies from requirements.txt automatically.
The app will be live at: https://[your-username]-[repo-name].streamlit.app

## Local testing (optional)
```
pip install -r requirements.txt
streamlit run app.py
```
